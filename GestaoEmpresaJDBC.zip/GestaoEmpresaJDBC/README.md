# Gestão de Empresa — JDBC + PostgreSQL

**Aluno:** Lucas Dias — Sistemas de Informação, UniLaSalle
**Disciplina:** Programação Orientada a Objetos

Sistema em modo texto para cadastrar **funcionários (empregados)** e **setores (departamentos)**,
atendendo ao enunciado: todo empregado tem CPF e nome, todo departamento tem sigla e nome,
todo empregado está alocado em um departamento e um departamento pode ter um empregado como gerente.

## Banco de dados

| Tabela | Colunas | Observações |
|---|---|---|
| `setor` | `sigla` (PK), `nome`, `cpf_gerente` | `cpf_gerente` é FK para `funcionario` e pode ser nulo |
| `funcionario` | `cpf` (PK), `nome`, `sigla_setor` | `sigla_setor` é FK obrigatória para `setor` |

As tabelas se referenciam mutuamente, então a FK do gerente é criada com `ALTER TABLE`
depois das duas tabelas existirem (ver `banco/script_empresa.sql`).

## Organização do código

```
src/br/com/lucasdias/gestao/
├── conexao/ConexaoBanco.java       -> abre conexões com o PostgreSQL
├── entidade/Setor.java             -> modelo do departamento
├── entidade/Funcionario.java       -> modelo do empregado
├── dao/SetorDAO.java               -> SQL da tabela setor
├── dao/FuncionarioDAO.java         -> SQL da tabela funcionario
├── dao/RegraNegocioException.java  -> erros de regra de negócio
├── ui/Entrada.java                 -> leitura do teclado
└── ui/SistemaEmpresa.java          -> menus (classe principal)
```

## Regras implementadas

- Não é possível cadastrar CPF ou sigla repetidos; o CPF precisa ter 11 dígitos
  (pode ser digitado com pontos e traço).
- Funcionário só pode ser cadastrado em um setor que já existe.
- O gerente de um setor precisa ser funcionário **daquele** setor.
- Setor com funcionários não pode ser excluído.
- Ao **excluir** ou **transferir** um funcionário que é gerente, a gerência do setor é
  liberada automaticamente, em uma **transação** (`commit`/`rollback`).

## Conceitos de JDBC utilizados

`DriverManager`, `Connection`, `PreparedStatement`, `ResultSet`, try-with-resources,
controle de transação com `setAutoCommit(false)`, `INNER JOIN` e `LEFT JOIN`.

## Como executar

1. Com o PostgreSQL rodando, crie o banco: `CREATE DATABASE empresa_db;`
2. Conectado em `empresa_db`, execute `banco/script_empresa.sql` (cria as tabelas e alguns dados de exemplo).
3. Se a senha do usuário `postgres` não for `postgres`, ajuste em `ConexaoBanco.java`.
4. No Eclipse: `File > Import > Existing Projects into Workspace` e selecione esta pasta.
5. Execute `br.com.lucasdias.gestao.ui.SistemaEmpresa` como *Java Application*.
