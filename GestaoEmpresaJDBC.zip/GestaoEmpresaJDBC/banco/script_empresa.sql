-- ------------------------------------------------------------
-- Exercicio JDBC + PostgreSQL - Gestao de Empresa
-- Autor: Lucas Dias
--
-- Passo 1: crie o banco (no psql ou no pgAdmin):
--     CREATE DATABASE empresa_db;
-- Passo 2: conecte no banco empresa_db e rode o restante do script.
-- ------------------------------------------------------------

DROP TABLE IF EXISTS funcionario CASCADE;
DROP TABLE IF EXISTS setor CASCADE;

-- Departamentos da empresa (identificados pela sigla)
CREATE TABLE setor (
    sigla        VARCHAR(10)  NOT NULL,
    nome         VARCHAR(80)  NOT NULL,
    cpf_gerente  CHAR(11),
    CONSTRAINT pk_setor PRIMARY KEY (sigla)
);

-- Empregados: todo empregado obrigatoriamente pertence a um departamento
CREATE TABLE funcionario (
    cpf          CHAR(11)     NOT NULL,
    nome         VARCHAR(80)  NOT NULL,
    sigla_setor  VARCHAR(10)  NOT NULL,
    CONSTRAINT pk_funcionario PRIMARY KEY (cpf),
    CONSTRAINT fk_funcionario_setor FOREIGN KEY (sigla_setor)
        REFERENCES setor (sigla)
);

-- O gerente de um departamento e um empregado. Como as duas tabelas
-- se referenciam, essa chave estrangeira so pode ser criada no final.
ALTER TABLE setor
    ADD CONSTRAINT fk_setor_gerente FOREIGN KEY (cpf_gerente)
        REFERENCES funcionario (cpf);

-- Dados de exemplo (opcional)
INSERT INTO setor (sigla, nome) VALUES
    ('TI',  'Tecnologia da Informacao'),
    ('RH',  'Recursos Humanos'),
    ('FIN', 'Financeiro');

INSERT INTO funcionario (cpf, nome, sigla_setor) VALUES
    ('11122233344', 'Ana Souza',      'TI'),
    ('22233344455', 'Bruno Lima',     'TI'),
    ('33344455566', 'Carla Mendes',   'RH'),
    ('44455566677', 'Diego Ferreira', 'FIN');

UPDATE setor SET cpf_gerente = '11122233344' WHERE sigla = 'TI';
UPDATE setor SET cpf_gerente = '33344455566' WHERE sigla = 'RH';
