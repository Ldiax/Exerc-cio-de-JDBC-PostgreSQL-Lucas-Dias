package br.com.lucasdias.gestao.entidade;

/**
 * Representa um empregado da empresa. Todo empregado pertence a um setor.
 */
public class Funcionario {

    private String cpf;
    private String nome;
    private String siglaSetor;
    private String nomeSetor; // usado apenas para exibicao

    public Funcionario(String cpf, String nome, String siglaSetor) {
        this.cpf = cpf;
        this.nome = nome;
        this.siglaSetor = siglaSetor;
    }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getSiglaSetor() { return siglaSetor; }
    public void setSiglaSetor(String siglaSetor) { this.siglaSetor = siglaSetor; }

    public String getNomeSetor() { return nomeSetor; }
    public void setNomeSetor(String nomeSetor) { this.nomeSetor = nomeSetor; }

    @Override
    public String toString() {
        String setor = nomeSetor != null ? siglaSetor + " - " + nomeSetor : siglaSetor;
        return cpf + "  " + nome + "  |  Setor: " + setor;
    }
}
