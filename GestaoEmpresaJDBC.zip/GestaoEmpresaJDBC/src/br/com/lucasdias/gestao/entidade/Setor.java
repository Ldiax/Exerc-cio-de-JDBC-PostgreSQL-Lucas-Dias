package br.com.lucasdias.gestao.entidade;

/**
 * Representa um departamento da empresa.
 */
public class Setor {

    private String sigla;
    private String nome;
    private String cpfGerente;   // pode ser nulo (setor sem gerente)
    private String nomeGerente;  // usado apenas para exibicao

    public Setor(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
    }

    public String getSigla() { return sigla; }
    public void setSigla(String sigla) { this.sigla = sigla; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpfGerente() { return cpfGerente; }
    public void setCpfGerente(String cpfGerente) { this.cpfGerente = cpfGerente; }

    public String getNomeGerente() { return nomeGerente; }
    public void setNomeGerente(String nomeGerente) { this.nomeGerente = nomeGerente; }

    public boolean temGerente() {
        return cpfGerente != null;
    }

    @Override
    public String toString() {
        String gerente = temGerente() ? nomeGerente + " - CPF " + cpfGerente : "(sem gerente)";
        return "[" + sigla + "] " + nome + "  |  Gerente: " + gerente;
    }
}
