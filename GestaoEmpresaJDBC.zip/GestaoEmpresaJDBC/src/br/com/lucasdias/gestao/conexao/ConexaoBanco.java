package br.com.lucasdias.gestao.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Centraliza os dados de acesso ao PostgreSQL.
 * Altere USUARIO e SENHA de acordo com a sua instalacao.
 */
public final class ConexaoBanco {

    private static final String URL = "jdbc:postgresql://localhost:5432/empresa_db";
    private static final String USUARIO = "postgres";
    private static final String SENHA = "postgres";

    private ConexaoBanco() {
        // classe utilitaria, nao deve ser instanciada
    }

    public static Connection abrir() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
