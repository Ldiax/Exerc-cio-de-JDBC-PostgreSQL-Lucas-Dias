package br.com.lucasdias.gestao.ui;

import java.util.Scanner;

/**
 * Leitura de dados do teclado com validacoes simples.
 */
public class Entrada {

    private final Scanner scanner = new Scanner(System.in);

    public String texto(String rotulo) {
        while (true) {
            System.out.print(rotulo + ": ");
            String valor = scanner.nextLine().trim();
            if (!valor.isEmpty()) {
                return valor;
            }
            System.out.println("  Campo obrigatorio.");
        }
    }

    /** Le uma sigla e padroniza em letras maiusculas. */
    public String sigla(String rotulo) {
        return texto(rotulo).toUpperCase();
    }

    /** Le um CPF aceitando pontos e traco, e devolve so os digitos. */
    public String cpf(String rotulo) {
        return texto(rotulo).replaceAll("[.\\-\\s]", "");
    }

    public int opcao(String rotulo) {
        while (true) {
            String valor = texto(rotulo);
            try {
                return Integer.parseInt(valor);
            } catch (NumberFormatException e) {
                System.out.println("  Digite um numero.");
            }
        }
    }

    public boolean confirmar(String pergunta) {
        String resposta = texto(pergunta + " (s/n)");
        return resposta.equalsIgnoreCase("s");
    }
}
