package br.com.lucasdias.gestao.ui;

import br.com.lucasdias.gestao.dao.FuncionarioDAO;
import br.com.lucasdias.gestao.dao.RegraNegocioException;
import br.com.lucasdias.gestao.dao.SetorDAO;
import br.com.lucasdias.gestao.entidade.Funcionario;
import br.com.lucasdias.gestao.entidade.Setor;

import java.sql.SQLException;
import java.util.List;

/**
 * Ponto de entrada do sistema de gestao de funcionarios e setores.
 * Execute esta classe como "Java Application" no Eclipse.
 */
public class SistemaEmpresa {

    private final Entrada entrada = new Entrada();
    private final SetorDAO setorDAO = new SetorDAO();
    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    public static void main(String[] args) {
        new SistemaEmpresa().iniciar();
    }

    private void iniciar() {
        System.out.println("=== SISTEMA DE GESTAO DA EMPRESA (JDBC + PostgreSQL) ===");
        boolean rodando = true;
        while (rodando) {
            System.out.println();
            System.out.println("1 - Setores (departamentos)");
            System.out.println("2 - Funcionarios (empregados)");
            System.out.println("3 - Relatorio geral");
            System.out.println("0 - Sair");
            switch (entrada.opcao("Escolha")) {
                case 1 -> menuSetores();
                case 2 -> menuFuncionarios();
                case 3 -> executar(this::relatorioGeral);
                case 0 -> rodando = false;
                default -> System.out.println("Opcao invalida.");
            }
        }
        System.out.println("Ate logo!");
    }

    // ------------------------------------------------------------------ setores

    private void menuSetores() {
        System.out.println();
        System.out.println("--- SETORES ---");
        System.out.println("1 - Cadastrar setor");
        System.out.println("2 - Listar setores");
        System.out.println("3 - Consultar setor e sua equipe");
        System.out.println("4 - Alterar nome do setor");
        System.out.println("5 - Definir gerente");
        System.out.println("6 - Retirar gerente");
        System.out.println("7 - Excluir setor");
        System.out.println("0 - Voltar");
        switch (entrada.opcao("Escolha")) {
            case 1 -> executar(() -> {
                String sigla = entrada.sigla("Sigla");
                String nome = entrada.texto("Nome");
                setorDAO.inserir(new Setor(sigla, nome));
                System.out.println("Setor cadastrado.");
            });
            case 2 -> executar(() -> imprimir(setorDAO.listar(), "Nenhum setor cadastrado."));
            case 3 -> executar(() -> {
                String sigla = entrada.sigla("Sigla");
                Setor setor = setorDAO.buscar(sigla)
                        .orElseThrow(() -> new RegraNegocioException("Setor nao encontrado."));
                System.out.println(setor);
                System.out.println("Equipe:");
                imprimir(funcionarioDAO.listarPorSetor(sigla), "  (nenhum funcionario)");
            });
            case 4 -> executar(() -> {
                String sigla = entrada.sigla("Sigla");
                setorDAO.renomear(sigla, entrada.texto("Novo nome"));
                System.out.println("Nome alterado.");
            });
            case 5 -> executar(() -> {
                String sigla = entrada.sigla("Sigla do setor");
                String cpf = entrada.cpf("CPF do novo gerente");
                setorDAO.definirGerente(sigla, cpf);
                System.out.println("Gerente definido.");
            });
            case 6 -> executar(() -> {
                setorDAO.retirarGerente(entrada.sigla("Sigla do setor"));
                System.out.println("Setor agora esta sem gerente.");
            });
            case 7 -> executar(() -> {
                String sigla = entrada.sigla("Sigla");
                if (entrada.confirmar("Confirma a exclusao do setor " + sigla + "?")) {
                    setorDAO.excluir(sigla);
                    System.out.println("Setor excluido.");
                }
            });
            case 0 -> { }
            default -> System.out.println("Opcao invalida.");
        }
    }

    // ------------------------------------------------------------- funcionarios

    private void menuFuncionarios() {
        System.out.println();
        System.out.println("--- FUNCIONARIOS ---");
        System.out.println("1 - Admitir funcionario");
        System.out.println("2 - Listar funcionarios");
        System.out.println("3 - Consultar por CPF");
        System.out.println("4 - Alterar nome");
        System.out.println("5 - Transferir de setor");
        System.out.println("6 - Desligar (excluir) funcionario");
        System.out.println("0 - Voltar");
        switch (entrada.opcao("Escolha")) {
            case 1 -> executar(() -> {
                String cpf = entrada.cpf("CPF (11 digitos)");
                String nome = entrada.texto("Nome");
                String sigla = entrada.sigla("Sigla do setor");
                funcionarioDAO.inserir(new Funcionario(cpf, nome, sigla));
                System.out.println("Funcionario admitido.");
            });
            case 2 -> executar(() -> imprimir(funcionarioDAO.listar(), "Nenhum funcionario cadastrado."));
            case 3 -> executar(() -> {
                String cpf = entrada.cpf("CPF");
                System.out.println(funcionarioDAO.buscar(cpf)
                        .map(Funcionario::toString)
                        .orElse("Funcionario nao encontrado."));
            });
            case 4 -> executar(() -> {
                String cpf = entrada.cpf("CPF");
                funcionarioDAO.renomear(cpf, entrada.texto("Novo nome"));
                System.out.println("Nome alterado.");
            });
            case 5 -> executar(() -> {
                String cpf = entrada.cpf("CPF");
                String sigla = entrada.sigla("Sigla do novo setor");
                funcionarioDAO.transferir(cpf, sigla);
                System.out.println("Transferencia realizada.");
            });
            case 6 -> executar(() -> {
                String cpf = entrada.cpf("CPF");
                if (entrada.confirmar("Confirma o desligamento do CPF " + cpf + "?")) {
                    funcionarioDAO.excluir(cpf);
                    System.out.println("Funcionario desligado.");
                }
            });
            case 0 -> { }
            default -> System.out.println("Opcao invalida.");
        }
    }

    // ---------------------------------------------------------------- relatorio

    private void relatorioGeral() throws SQLException {
        List<Setor> setores = setorDAO.listar();
        if (setores.isEmpty()) {
            System.out.println("Nenhum setor cadastrado.");
            return;
        }
        for (Setor setor : setores) {
            List<Funcionario> equipe = funcionarioDAO.listarPorSetor(setor.getSigla());
            System.out.println();
            System.out.println(setor);
            System.out.println("  Total de funcionarios: " + equipe.size());
            for (Funcionario f : equipe) {
                String marca = f.getCpf().equals(setor.getCpfGerente()) ? " (gerente)" : "";
                System.out.println("   - " + f.getNome() + marca);
            }
        }
    }

    // ---------------------------------------------------------------- utilidades

    @FunctionalInterface
    private interface Acao {
        void rodar() throws SQLException, RegraNegocioException;
    }

    /** Executa uma acao tratando os erros de forma amigavel para o usuario. */
    private void executar(Acao acao) {
        try {
            acao.rodar();
        } catch (RegraNegocioException e) {
            System.out.println("Atencao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro de banco de dados: " + e.getMessage());
        }
    }

    private void imprimir(List<?> itens, String mensagemVazia) {
        if (itens.isEmpty()) {
            System.out.println(mensagemVazia);
        } else {
            itens.forEach(System.out::println);
        }
    }
}
