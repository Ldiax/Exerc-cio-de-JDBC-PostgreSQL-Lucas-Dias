package br.com.lucasdias.gestao.dao;

import br.com.lucasdias.gestao.conexao.ConexaoBanco;
import br.com.lucasdias.gestao.entidade.Funcionario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Operacoes de banco referentes a tabela "funcionario" (empregados).
 */
public class FuncionarioDAO {

    private static final String SELECT_BASE =
            "SELECT f.cpf, f.nome, f.sigla_setor, s.nome AS nome_setor "
          + "FROM funcionario f INNER JOIN setor s ON s.sigla = f.sigla_setor ";

    public void inserir(Funcionario func) throws SQLException, RegraNegocioException {
        validarCpf(func.getCpf());
        if (buscar(func.getCpf()).isPresent()) {
            throw new RegraNegocioException("Ja existe um funcionario com o CPF " + func.getCpf() + ".");
        }
        garantirSetorExiste(func.getSiglaSetor());

        String sql = "INSERT INTO funcionario (cpf, nome, sigla_setor) VALUES (?, ?, ?)";
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, func.getCpf());
            ps.setString(2, func.getNome());
            ps.setString(3, func.getSiglaSetor());
            ps.executeUpdate();
        }
    }

    public List<Funcionario> listar() throws SQLException {
        return consultarLista(SELECT_BASE + "ORDER BY f.nome", null);
    }

    public List<Funcionario> listarPorSetor(String sigla) throws SQLException {
        return consultarLista(SELECT_BASE + "WHERE f.sigla_setor = ? ORDER BY f.nome", sigla);
    }

    public Optional<Funcionario> buscar(String cpf) throws SQLException {
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(SELECT_BASE + "WHERE f.cpf = ?")) {
            ps.setString(1, cpf);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(montar(rs)) : Optional.empty();
            }
        }
    }

    public void renomear(String cpf, String novoNome) throws SQLException, RegraNegocioException {
        String sql = "UPDATE funcionario SET nome = ? WHERE cpf = ?";
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, novoNome);
            ps.setString(2, cpf);
            if (ps.executeUpdate() == 0) {
                throw new RegraNegocioException("Funcionario " + cpf + " nao encontrado.");
            }
        }
    }

    /**
     * Move o funcionario para outro setor. Se ele era gerente do setor
     * antigo, a gerencia e liberada na mesma transacao.
     */
    public void transferir(String cpf, String novaSigla) throws SQLException, RegraNegocioException {
        if (buscar(cpf).isEmpty()) {
            throw new RegraNegocioException("Funcionario " + cpf + " nao encontrado.");
        }
        garantirSetorExiste(novaSigla);

        try (Connection con = ConexaoBanco.abrir()) {
            con.setAutoCommit(false);
            try {
                liberarGerencia(con, cpf);
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE funcionario SET sigla_setor = ? WHERE cpf = ?")) {
                    ps.setString(1, novaSigla);
                    ps.setString(2, cpf);
                    ps.executeUpdate();
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    /**
     * Exclui o funcionario. Se ele for gerente de algum setor, o setor
     * fica sem gerente (tudo dentro de uma unica transacao).
     */
    public void excluir(String cpf) throws SQLException, RegraNegocioException {
        try (Connection con = ConexaoBanco.abrir()) {
            con.setAutoCommit(false);
            try {
                liberarGerencia(con, cpf);
                int removidos;
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM funcionario WHERE cpf = ?")) {
                    ps.setString(1, cpf);
                    removidos = ps.executeUpdate();
                }
                if (removidos == 0) {
                    con.rollback();
                    throw new RegraNegocioException("Funcionario " + cpf + " nao encontrado.");
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    // ----------------------------------------------------------------- auxiliares

    private void liberarGerencia(Connection con, String cpf) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE setor SET cpf_gerente = NULL WHERE cpf_gerente = ?")) {
            ps.setString(1, cpf);
            ps.executeUpdate();
        }
    }

    private void garantirSetorExiste(String sigla) throws SQLException, RegraNegocioException {
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement("SELECT 1 FROM setor WHERE sigla = ?")) {
            ps.setString(1, sigla);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new RegraNegocioException("Setor " + sigla + " nao existe. Cadastre-o primeiro.");
                }
            }
        }
    }

    private void validarCpf(String cpf) throws RegraNegocioException {
        if (cpf == null || !cpf.matches("\\d{11}")) {
            throw new RegraNegocioException("CPF deve ter exatamente 11 digitos numericos.");
        }
    }

    private List<Funcionario> consultarLista(String sql, String parametro) throws SQLException {
        List<Funcionario> lista = new ArrayList<>();
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (parametro != null) {
                ps.setString(1, parametro);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(montar(rs));
                }
            }
        }
        return lista;
    }

    private Funcionario montar(ResultSet rs) throws SQLException {
        Funcionario f = new Funcionario(rs.getString("cpf"), rs.getString("nome"), rs.getString("sigla_setor"));
        f.setNomeSetor(rs.getString("nome_setor"));
        return f;
    }
}
