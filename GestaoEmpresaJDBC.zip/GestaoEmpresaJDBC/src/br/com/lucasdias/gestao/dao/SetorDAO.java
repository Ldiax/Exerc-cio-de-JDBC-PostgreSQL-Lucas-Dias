package br.com.lucasdias.gestao.dao;

import br.com.lucasdias.gestao.conexao.ConexaoBanco;
import br.com.lucasdias.gestao.entidade.Setor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Operacoes de banco referentes a tabela "setor" (departamentos).
 */
public class SetorDAO {

    private static final String SELECT_BASE =
            "SELECT s.sigla, s.nome, s.cpf_gerente, f.nome AS nome_gerente "
          + "FROM setor s LEFT JOIN funcionario f ON f.cpf = s.cpf_gerente ";

    public void inserir(Setor setor) throws SQLException, RegraNegocioException {
        if (buscar(setor.getSigla()).isPresent()) {
            throw new RegraNegocioException("Ja existe um setor com a sigla " + setor.getSigla() + ".");
        }
        String sql = "INSERT INTO setor (sigla, nome) VALUES (?, ?)";
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, setor.getSigla());
            ps.setString(2, setor.getNome());
            ps.executeUpdate();
        }
    }

    public List<Setor> listar() throws SQLException {
        List<Setor> setores = new ArrayList<>();
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(SELECT_BASE + "ORDER BY s.sigla");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                setores.add(montar(rs));
            }
        }
        return setores;
    }

    public Optional<Setor> buscar(String sigla) throws SQLException {
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(SELECT_BASE + "WHERE s.sigla = ?")) {
            ps.setString(1, sigla);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(montar(rs)) : Optional.empty();
            }
        }
    }

    public void renomear(String sigla, String novoNome) throws SQLException, RegraNegocioException {
        String sql = "UPDATE setor SET nome = ? WHERE sigla = ?";
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, novoNome);
            ps.setString(2, sigla);
            if (ps.executeUpdate() == 0) {
                throw new RegraNegocioException("Setor " + sigla + " nao encontrado.");
            }
        }
    }

    /**
     * Define o gerente do setor. O funcionario precisa existir e
     * precisa estar lotado no proprio setor que vai gerenciar.
     */
    public void definirGerente(String sigla, String cpf) throws SQLException, RegraNegocioException {
        if (buscar(sigla).isEmpty()) {
            throw new RegraNegocioException("Setor " + sigla + " nao encontrado.");
        }
        String consulta = "SELECT sigla_setor FROM funcionario WHERE cpf = ?";
        String atualizacao = "UPDATE setor SET cpf_gerente = ? WHERE sigla = ?";
        try (Connection con = ConexaoBanco.abrir()) {
            try (PreparedStatement ps = con.prepareStatement(consulta)) {
                ps.setString(1, cpf);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new RegraNegocioException("Nao existe funcionario com o CPF " + cpf + ".");
                    }
                    if (!sigla.equals(rs.getString("sigla_setor"))) {
                        throw new RegraNegocioException(
                                "O funcionario precisa pertencer ao setor " + sigla + " para ser o gerente.");
                    }
                }
            }
            try (PreparedStatement ps = con.prepareStatement(atualizacao)) {
                ps.setString(1, cpf);
                ps.setString(2, sigla);
                ps.executeUpdate();
            }
        }
    }

    public void retirarGerente(String sigla) throws SQLException, RegraNegocioException {
        String sql = "UPDATE setor SET cpf_gerente = NULL WHERE sigla = ?";
        try (Connection con = ConexaoBanco.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sigla);
            if (ps.executeUpdate() == 0) {
                throw new RegraNegocioException("Setor " + sigla + " nao encontrado.");
            }
        }
    }

    public void excluir(String sigla) throws SQLException, RegraNegocioException {
        String contagem = "SELECT COUNT(*) FROM funcionario WHERE sigla_setor = ?";
        String exclusao = "DELETE FROM setor WHERE sigla = ?";
        try (Connection con = ConexaoBanco.abrir()) {
            try (PreparedStatement ps = con.prepareStatement(contagem)) {
                ps.setString(1, sigla);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    int qtd = rs.getInt(1);
                    if (qtd > 0) {
                        throw new RegraNegocioException("O setor " + sigla + " ainda possui " + qtd
                                + " funcionario(s). Transfira ou exclua-os antes.");
                    }
                }
            }
            try (PreparedStatement ps = con.prepareStatement(exclusao)) {
                ps.setString(1, sigla);
                if (ps.executeUpdate() == 0) {
                    throw new RegraNegocioException("Setor " + sigla + " nao encontrado.");
                }
            }
        }
    }

    private Setor montar(ResultSet rs) throws SQLException {
        Setor s = new Setor(rs.getString("sigla"), rs.getString("nome"));
        s.setCpfGerente(rs.getString("cpf_gerente"));
        s.setNomeGerente(rs.getString("nome_gerente"));
        return s;
    }
}
