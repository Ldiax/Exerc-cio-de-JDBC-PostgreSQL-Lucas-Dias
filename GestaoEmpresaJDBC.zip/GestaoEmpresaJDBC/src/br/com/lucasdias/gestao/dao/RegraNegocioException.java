package br.com.lucasdias.gestao.dao;

/**
 * Lancada quando uma operacao fere alguma regra do sistema
 * (ex.: excluir um setor que ainda possui funcionarios).
 */
public class RegraNegocioException extends Exception {

    private static final long serialVersionUID = 1L;

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
